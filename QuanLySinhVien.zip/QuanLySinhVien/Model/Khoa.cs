﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Model
{
    public class Khoa:DoiTuong
    {   
        public Khoa() { }
        public Khoa(string maKhoa, string tenKhoa):base(maKhoa, tenKhoa)
        {
        }
    }
}
