﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Model
{
    public abstract class DoiTuong
    {
        public string Ma { get; set; }
        public string Ten { get; set; }
        public DoiTuong()
        {

        }
        public DoiTuong(string ma, string ten)
        {
            Ma = ma;
            Ten = ten;
        }
    }
}
