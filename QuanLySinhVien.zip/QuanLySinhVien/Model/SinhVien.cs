﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Model
{
    public class SinhVien: DoiTuong
    {
       
        public DateTime NgaySinh { get; set; }
        public string NoiSinh { get; set; }
        public string GioiTinh { get; set; }
      
        public string SDT { get; set; }
        public string Email { get; set; }

        public string MaLop { get; set; }
        public SinhVien() { }
        public SinhVien(string maSV, string hoTen, DateTime ngaySinh,  string noiSinh, string gioiTinh, string sdt, string email,string maLop): base(maSV, hoTen)
        {
            NgaySinh = ngaySinh;
            NoiSinh = noiSinh;
            GioiTinh = gioiTinh;
            SDT = sdt;
            Email = email;
            MaLop = maLop;
        }
    }
}
