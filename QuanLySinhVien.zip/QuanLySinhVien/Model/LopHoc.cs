﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Model
{
    public class LopHoc: DoiTuong
    {
        public int SiSo { get; set; }
        public string MaKhoa { get; set; }
        
        public LopHoc( string maLop, string tenLop, int siSo, string maKhoa): base(maLop, tenLop)
        {
            
            this.SiSo = siSo;
            this.MaKhoa = maKhoa;
        }
    }
}
