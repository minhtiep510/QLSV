﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Model
{
    public class Diem
    {
        public string MaSV { get; set; }
        public string MaMH { get; set; }
        
        public double DiemSo { get; set; }
        public string XepLoai { get; set; }
       public static string getXepLoai(double DiemSo)
        {
            if (DiemSo>=8.5)
            {
                return "A";
            }
            else if (DiemSo >= 7)
            {
                return "B";
            }
            else if(DiemSo >= 5.5)
            {
                return "C";
            }
            else if (DiemSo >= 4)
            {
                return "D";
            }
            else
            {
                return "F";
            }
        }
        public Diem() { }
        public Diem( string maSV, string maMH, double diemSo,string xepLoai)
        {
            MaSV = maSV;
            MaMH = maMH;
            DiemSo = diemSo;
            XepLoai = xepLoai;

        }
    }
}
