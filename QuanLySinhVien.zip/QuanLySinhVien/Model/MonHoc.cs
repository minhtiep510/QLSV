﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Model
{
    public class MonHoc: DoiTuong
    {
        public int SoTiet{ get; set; }
        public int HocKy { get; set; }

        public MonHoc() { }
        public MonHoc( string maMH, string tenMH, int soTiet, int hocKy):base(maMH, tenMH)
        {
            SoTiet = soTiet;
            HocKy = hocKy;
        }
    }
}
