﻿using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;

namespace QuanLySinhVien.Database
{
    public class QuanLySV
    {
        private string connectionString = "Data Source=DESKTOP-KAPJVN9;Initial Catalog=QLSINHVIEN;User ID=sa;Password=minhtiep;";

        // 📘 Lấy toàn bộ sinh viên
        public List<SinhVien> getAll()
        {
            List<SinhVien> danhSach = new List<SinhVien>();

            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                string sql = "SELECT * FROM SINHVIEN";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    SinhVien sv = new SinhVien();
                    sv.Ma = reader["MASV"].ToString();
                    sv.Ten = reader["TENSV"].ToString();
                    sv.NgaySinh = Convert.ToDateTime(reader["NGAYSINH"]);
                    sv.NoiSinh = reader["NOISINH"].ToString();
                    sv.GioiTinh = reader["GIOITINH"].ToString();
                    sv.SDT = reader["SDT"].ToString();
                    sv.Email = reader["EMAIL"].ToString();
                    sv.MaLop = reader["MALOP"].ToString();
                    danhSach.Add(sv);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);

            }
            return danhSach;
        } 


        // 📗 Thêm sinh viên
            public bool them(SinhVien sv)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(connectionString)) { 
                    conn.Open();
                    String sql = "INSERT INTO SinhVien  (MASV, TENSV, NGAYSINH, NOISINH, GIOITINH, SDT, EMAIL, MALOP)   VALUES(@MASV,@TENSV,@NGAYSINH,@NOISINH,@GIOITINH,@SDT,@EMAIL,@MALOP)";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@MASV", sv.Ma);
                    cmd.Parameters.AddWithValue("@TENSV", sv.Ten);
                    cmd.Parameters.AddWithValue("@NGAYSINH", sv.NgaySinh);
                    cmd.Parameters.AddWithValue("@NOISINH", sv.NoiSinh);
                    cmd.Parameters.AddWithValue("@GIOITINH", sv.GioiTinh);
                    cmd.Parameters.AddWithValue("@SDT", sv.SDT);
                    cmd.Parameters.AddWithValue("@EMAIL", sv.Email);
                    cmd.Parameters.AddWithValue("@MALOP", sv.MaLop);
                    int row=cmd.ExecuteNonQuery();
                    return row > 0;
                }
                } catch (Exception ex)
                {
                    Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
                }

            }
        public bool Xoa(String MaSV)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                String sql = "DELETE FROM SinhVien WHERE MASV = @MASV";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MASV",MaSV);
                int row= cmd.ExecuteNonQuery();
                conn.Close();
                return row >0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public bool Update(SinhVien sv)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                String sql = "Update SinhVien Set TENSV=@TENSV,NGAYSINH=@NGAYSINH,NOISINH=@NOISINH,GIOITINH=@GIOITINH,SDT=@SDT,Email=@Email, MALOP=@MALOP where MASV=@MASV";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@TENSV", sv.Ten);
                cmd.Parameters.AddWithValue("@NGAYSINH", sv.NgaySinh);
                cmd.Parameters.AddWithValue("@NOISINH", sv.NoiSinh);
                cmd.Parameters.AddWithValue("@GIOITINH", sv.GioiTinh);
                cmd.Parameters.AddWithValue("@SDT", sv.SDT);
                cmd.Parameters.AddWithValue("@Email", sv.Email);
                cmd.Parameters.AddWithValue("@MALOP", sv.MaLop);
                cmd.Parameters.AddWithValue("@MASV", sv.Ma);
                int kq = cmd.ExecuteNonQuery();
                conn.Close();
                return kq > 0;
                

            }
            catch(Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public bool checkMa(string maSV)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                String sql = "SELECT COUNT(*) FROM SINHVIEN WHERE MASV = @MASV";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MASV", maSV);
                int count = (int)cmd.ExecuteScalar();
                conn.Close();
                return count > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public List<SinhVien> timkiemMa(string maSV)
        {
            List<SinhVien> ds = new List<SinhVien>();
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "SELECT * from SINHVIEN WHERE MASV=@MASV";
                SqlCommand cmd = new SqlCommand(sql,conn);
                cmd.Parameters.AddWithValue("@MASV", maSV);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    SinhVien sv = new SinhVien();
                    sv.Ma = reader["MASV"].ToString();
                    sv.Ten = reader["TENSV"].ToString();
                    sv.NgaySinh = Convert.ToDateTime(reader["NGAYSINH"]);
                    sv.NoiSinh = reader["NOISINH"].ToString();
                    sv.GioiTinh = reader["GIOITINH"].ToString();
                    sv.SDT = reader["SDT"].ToString();
                    sv.Email = reader["EMAIL"].ToString();
                    sv.MaLop = reader["MALOP"].ToString();
                    ds.Add(sv);
                }
            }
            catch (Exception ex)
            { }

            return ds;
        }
        public int SoLuongSV()
        {
            int count = 0;
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "SELECT COUNT(*) FROM SINHVIEN";
                SqlCommand cmd = new SqlCommand(sql, conn);
                count = (int)cmd.ExecuteScalar();
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
            }
            return count;
        }
    }
}
