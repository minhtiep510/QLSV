﻿using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace QuanLySinhVien.Database
{
    public class QuanLyMonHoc
    {
        private string connectionString = @"Data Source=DESKTOP-KAPJVN9;Initial Catalog=QLSINHVIEN;User ID=sa;Password=minhtiep;";
        public List<MonHoc> getAll()
        {
            List<MonHoc> danhSach = new List<MonHoc>();
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string query = "SELECT * FROM MONHOC";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string maMH = reader["MAMH"].ToString();
                    string tenMH = reader["TENMH"].ToString();
                    int soTiet = Convert.ToInt32(reader["SOTIET"]);
                    int hocKy = Convert.ToInt32(reader["HOCKY"]);
                    danhSach.Add(new MonHoc(maMH, tenMH,soTiet, hocKy));
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
            }
            return danhSach;
        }
        public bool them(MonHoc mh)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "INSERT INTO MONHOC (MAMH, TENMH, SOTIET, HOCKY) VALUES(@MAMH, @TENMH, @SOTIET, @HOCKY)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MAMH", mh.Ma);
                cmd.Parameters.AddWithValue("@TENMH", mh.Ten);
                cmd.Parameters.AddWithValue("@SOTIET", mh.SoTiet);
                cmd.Parameters.AddWithValue("@HOCKY", mh.HocKy);
                int row = cmd.ExecuteNonQuery();
                conn.Close();
                return row > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public bool xoa(string maMH)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "DELETE FROM MONHOC WHERE MAMH = @MAMH";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MAMH", maMH);
                int row = cmd.ExecuteNonQuery();
                conn.Close();
                return row > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public bool sua(MonHoc mh)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "UPDATE MONHOC SET TENMH = @TENMH, SOTIET = @SOTIET, HOCKY = @HOCKY WHERE MAMH = @MAMH";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MAMH", mh.Ma);
                cmd.Parameters.AddWithValue("@TENMH", mh.Ten);
                cmd.Parameters.AddWithValue("@SOTIET", mh.SoTiet);
                cmd.Parameters.AddWithValue("@HOCKY", mh.HocKy);
                int row = cmd.ExecuteNonQuery();
                conn.Close();
                return row > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public bool checkMaMH(string maMH)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "SELECT COUNT(*) FROM MONHOC WHERE MAMH = @MAMH";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MAMH", maMH);
                int count = (int)cmd.ExecuteScalar();
                conn.Close();
                return count > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public List<MonHoc> timkiemMa(string maMH)
        {
            List<MonHoc> danhSach=new List<MonHoc>();
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "SELECT * FROM MONHOC WHERE MAMH = @MAMH";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MAMH", maMH);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string mamH = reader["MAMH"].ToString();
                    string tenMH = reader["TENMH"].ToString();
                    int soTiet = Convert.ToInt32(reader["SOTIET"]);
                    int hocKy = Convert.ToInt32(reader["HOCKY"]);
                    danhSach.Add(new MonHoc(mamH, tenMH, soTiet, hocKy));
                }
            }
            catch (Exception ex)
            {
            }
            return danhSach;
        }
        public int SoLuongMH()
        {
            int count = 0;
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "SELECT COUNT(*) FROM MONHOC";
                SqlCommand cmd = new SqlCommand(sql, conn);
                count = (int)cmd.ExecuteScalar();
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
            }
            return count;
        }
    }
}
