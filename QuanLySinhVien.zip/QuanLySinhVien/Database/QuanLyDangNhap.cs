﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.Identity.Client;
using QuanLySinhVien.Model;

namespace QuanLySinhVien.Database
{
    public class QuanLyDangNhap
    {   
        
        private string connectionString = "Data Source=DESKTOP-KAPJVN9;Initial Catalog=QLSINHVIEN;User ID=sa;Password=minhtiep;";
        public bool KiemTraDangNhap(string username, string password)
        {
            using(SqlConnection conn=new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Users WHERE username=@username AND password=@password";
                using(SqlCommand cmd=new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return true; 
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            
        }
        public bool DoiMatKhau(string username, string oldPassword, string newPassword)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "UPDate users set password=@newPassword where username=@username and password =@newPassword";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@newPassword", newPassword);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@oldPassword", oldPassword);
                int row = cmd.ExecuteNonQuery();
                conn.Close();
                return row > 0;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
