﻿using Microsoft.Data.SqlClient;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Database
{
     public class QuanLyDiem
    {
       private string connectionString= @"Data Source=DESKTOP-KAPJVN9;Initial Catalog=QLSINHVIEN;User ID=sa;Password=minhtiep;";
       public List<Diem> getAll()
        {
            List<Diem> ds= new List<Diem>();
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "SELECT * FROM DIEM";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string maSv = reader["MASV"].ToString();
                    string maMh = reader["MAMH"].ToString();
                    double diem = Convert.ToDouble(reader["Diem"].ToString());
                    string xeploai = reader["XEPLOAI"].ToString();
                    ds.Add(new Diem(maSv, maMh, diem, xeploai));
                }
                conn.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ds;
        }
        public bool them(Diem diem)
        {

            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "INSERT INTO DIEM VALUES(@MASV,@MAMH,@DIEM,@XEPLOAI)";
                SqlCommand cmd = new SqlCommand(sql, conn);;
                cmd.Parameters.AddWithValue("@MASV", diem.MaSV);
                cmd.Parameters.AddWithValue("@MAMH", diem.MaMH);
                cmd.Parameters.AddWithValue("@DIEM", diem.DiemSo);
                cmd.Parameters.AddWithValue("@XEPLOAI", Diem.getXepLoai(diem.DiemSo));
                int row = cmd.ExecuteNonQuery();
                return row > 0;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool sua(Diem diem)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "UPDATE DIEM SET DIEM=@DIEM,XEPLOAI=@XEPLOAI WHERE MASV=@MASV and MAMH=@MAMH";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@DIEM", diem.DiemSo);
                cmd.Parameters.AddWithValue("@XEPLOAI", Diem.getXepLoai(diem.DiemSo));
                cmd.Parameters.AddWithValue("@MAMH", diem.MaMH);
                cmd.Parameters.AddWithValue("@MASV", diem.MaSV);
                int row = cmd.ExecuteNonQuery();
                return row > 0;
            }
            catch
            {
                return false;
            }
        }
        public bool xoa(string MaSV, string MaMH)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "DELETE FROM DIEM WHERE MASV=@MASV and MAMH=@MAMH";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MASV", MaSV);
                cmd.Parameters.AddWithValue("@MAMH", MaMH);
                int row = cmd.ExecuteNonQuery();
                return row > 0;
            }
            catch
            {
                return false;
            }
        }
    }
}
