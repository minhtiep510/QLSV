﻿using Microsoft.Data.SqlClient;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.Pkcs;
using System.Text;
using System.Threading.Tasks;

namespace QuanLySinhVien.Database
{
    public class QuanLyKhoa
    {
        private string connectionString = @"Data Source=DESKTOP-KAPJVN9;Initial Catalog=QLSINHVIEN;User ID=sa;Password=minhtiep;";
        public List<Khoa> getAll()
        {
            List<Khoa> danhSach = new List<Khoa>();
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string query = "SELECT * FROM KHOA";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string maKhoa = reader["MAKHOA"].ToString();
                    string tenKhoa = reader["TENKHOA"].ToString();
                    danhSach.Add(new Khoa(maKhoa, tenKhoa));

                }
                conn.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);

            }
            return danhSach;
        }
        public bool Them(Khoa kh)
        {
            try
            {
                    SqlConnection conn = new SqlConnection(connectionString);
                    conn.Open();
                    String sql = "INSERT INTO KHOA  VALUES(@MAKHOA,@TENKHOA)";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@MAKHOA", kh.Ma);
                    cmd.Parameters.AddWithValue("@TENKHOA", kh.Ten);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();
                    return rowsAffected > 0;
              }
            catch (Exception ex)
            {
               
                return false;
            }
        }
        public bool Xoa(String MaKhoa)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                String sql = "DELETE FROM KHOA WHERE MAKHOA = @MAKHOA";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MAKHOA", MaKhoa);
                int row = cmd.ExecuteNonQuery();
                conn.Close();
                return row > 0;
            }
            catch (Exception ex)
            {
                
                return false;
            }
        }
        public bool Sua(Khoa kh)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                String sql = "UPDATE KHOA SET TENKHOA = @TENKHOA WHERE MAKHOA = @MAKHOA";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@MAKHOA", kh.Ma);
                cmd.Parameters.AddWithValue("@TENKHOA", kh.Ten);
                int row = cmd.ExecuteNonQuery();
                conn.Close();
                return row > 0;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public List<string> getMa()
        {
            List<string> danhSach = new List<string>();
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string query = "SELECT MAKHOA FROM KHOA";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string maKhoa = reader["MAKHOA"].ToString();
                    danhSach.Add(maKhoa);
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
            }
            return danhSach;
        }
        public bool checkMa(string maKhoa)
        {
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string query = "SELECT COUNT(*) FROM KHOA WHERE MAKHOA = @MAKHOA";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MAKHOA", maKhoa);
                int count = (int)cmd.ExecuteScalar();
                conn.Close();
                return count > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public List<Khoa> timkiemMa(string maKhoa)
        {
            List<Khoa> danhSach = new List<Khoa>();
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                String query = "SELECT* From KHOA WHERE MAKHOA=@MAKHOA";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@MAKHOA", maKhoa);
                SqlDataReader reader = cmd.ExecuteReader();
                if(reader.Read())
                {
                    string makhoa = reader["MAKHOA"].ToString();
                    string tenKhoa = reader["TENKHOA"].ToString();
                    danhSach.Add(new Khoa(makhoa,tenKhoa));
                   
                }
                reader.Close();
                conn.Close();
                
            }
            catch(Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
            }
            return danhSach;
        }
        public int SoLuongKhoa()
        {
            int count = 0;
            try
            {
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                string query = "SELECT COUNT(*) FROM KHOA";
                SqlCommand cmd = new SqlCommand(query, conn);
                count = (int)cmd.ExecuteScalar();
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
            }
            return count;
        }
    }
}
