﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using QuanLySinhVien.Model;

namespace QuanLySinhVien.Database
{
    public class QuanLyLopHoc
    {
        private string stringConnection = @"Data Source=DESKTOP-KAPJVN9;Initial Catalog=QLSINHVIEN;User ID=sa;Password=minhtiep;";
        public List<LopHoc> getAll()
        {
            List<LopHoc> danhSach = new List<LopHoc>();
            try
            {
                SqlConnection conn = new SqlConnection(stringConnection);
                conn.Open();
                string query = "SELECT * FROM LOPHOC";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string maLop = reader["MALOP"].ToString();
                    string tenLop = reader["TENLOP"].ToString();
                    int siSo = Convert.ToInt32(reader["SISODK"]);
                    string maKhoa = reader["MAKHOA"].ToString();
                    danhSach.Add(new LopHoc(maLop, tenLop, siSo, maKhoa));
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
            }
            return danhSach;
        }
        public bool Them(LopHoc lh)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(stringConnection))
                {
                    conn.Open();
                    String sql = "INSERT INTO LOPHOC  (MALOP, TENLOP, SISODK, MAKHOA) VALUES(@MALOP,@TENLOP,@SISO,@MAKHOA)";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@MALOP", lh.Ma);
                    cmd.Parameters.AddWithValue("@TENLOP", lh.Ten);
                    cmd.Parameters.AddWithValue("@SISO", lh.SiSo);
                    cmd.Parameters.AddWithValue("@MAKHOA", lh.MaKhoa);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public bool Xoa(string maLop)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(stringConnection))
                {
                    conn.Open();
                    String sql = "DELETE FROM LOPHOC WHERE MALOP = @MALOP";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@MALOP", maLop);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public bool Sua(LopHoc lh)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(stringConnection))
                {
                    conn.Open();
                    String sql = "UPDATE LOPHOC SET TENLOP = @TENLOP, SISODK = @SISO, MAKHOA = @MAKHOA WHERE MALOP = @MALOP";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@TENLOP", lh.Ten);
                    cmd.Parameters.AddWithValue("@SISO", lh.SiSo);
                    cmd.Parameters.AddWithValue("@MAKHOA", lh.MaKhoa);
                    cmd.Parameters.AddWithValue("@MALOP", lh.Ma);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public bool checkMa(string maLop)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(stringConnection))
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM LOPHOC WHERE MALOP = @MALOP";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@MALOP", maLop);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
                return false;
            }
        }
        public List<LopHoc> timkiemMa(string maLop)
        { 
            List<LopHoc> ds = new List<LopHoc>();
            try
            {
                SqlConnection conn = new SqlConnection(stringConnection);
                conn.Open();
                string query = "SELECT * From LOPHOC WHERE MALOp=@MALOP";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string malop = reader["MALOP"].ToString();
                    string tenLop = reader["TENLOP"].ToString();
                    int siSo = Convert.ToInt32(reader["SISODK"]);
                    string maKhoa = reader["MAKHOA"].ToString();
                    ds.Add(new LopHoc(malop, tenLop, siSo, maKhoa));
                }
                conn.Close();
                reader.Close();
            }
            catch (Exception ex) { }
            return ds;

        }
         public int SoLuongLop()
        {
            int count = 0;
            try
            {
                using (SqlConnection conn = new SqlConnection(stringConnection))
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM LOPHOC";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    count = (int)cmd.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Lỗi khi kết nối cơ sở dữ liệu: " + ex.Message);
            }
            return count;
        }
    }
    
}
