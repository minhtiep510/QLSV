﻿
using QuanLySinhVien.Database;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.view
{
    public partial class frmDiem : Form
    {
        private QuanLyDiem ds = new QuanLyDiem();
        private QuanLySV ds1 = new QuanLySV();
        public QuanLyMonHoc ds2 = new QuanLyMonHoc();
        public frmDiem()
        {
            InitializeComponent();
        }
        public void LoadTable()
        {
            dataGridView1.DataSource = ds.getAll();
            dataGridView1.Columns["MASV"].DisplayIndex = 0;
            dataGridView1.Columns["MAMH"].DisplayIndex = 1;
            dataGridView1.Columns["DIEMSO"].DisplayIndex = 2;
            dataGridView1.Columns["XEPLOAI"].DisplayIndex = 3;
            dataGridView1.Columns["MASV"].HeaderText = "Mã sinh viên";
            dataGridView1.Columns["MAMH"].HeaderText = "Mã môn học";
            dataGridView1.Columns["DIEMSO"].HeaderText = "Điểm";
            dataGridView1.Columns["XEPLOAI"].HeaderText = "Xếp loại";
        }
        public void clearForm()
        {
            textBox1.ReadOnly = false;
            textBox2.ReadOnly = false;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show(this, "Vui lòng nhập đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    string maSV = textBox1.Text;
                    string maMH = textBox2.Text;
                    double diem = Convert.ToDouble(textBox3.Text);
                    if (diem < 0 || diem > 10)
                    {
                        MessageBox.Show(this, "Điểm phải lớn hơn 0 và nhỏ hơn 10", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        bool kq = ds.them(new Diem(maSV, maMH, diem, Diem.getXepLoai(diem)));
                        if (kq)
                        {
                            LoadTable();
                            clearForm();
                        }
                        else
                        {
                            if (!ds1.checkMa(maSV))
                            {
                                MessageBox.Show(this, "Mã sinh viên không tồn tại", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            else if (!ds2.checkMaMH(maMH))
                            {
                                MessageBox.Show(this, "Mã môn học không tồn tại", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            else
                            {
                                MessageBox.Show(this, "Thêm không thành công", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                        }

                    }
                }
                catch
                {
                    MessageBox.Show(this, "Điểm phải có dạng chữ số", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void frmDiem_Load(object sender, EventArgs e)
        {
            LoadTable();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show(this, "Vui lòng nhập đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                try
                {
                    string maSV = textBox1.Text;
                    string maMH = textBox2.Text;
                    double diem = Convert.ToDouble(textBox3.Text);
                    if (diem < 0 || diem > 10)
                    {
                        MessageBox.Show(this, "Điểm phải lớn hơn 0 và nhỏ hơn 10", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        bool kq = ds.sua(new Diem(maSV, maMH, diem, Diem.getXepLoai(diem)));
                        if (kq)
                        {
                            LoadTable();
                            clearForm();
                        }
                        else
                        {
                            if (!ds1.checkMa(maSV))
                            {
                                MessageBox.Show(this, "Mã sinh viên không tồn tại", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            else if (!ds2.checkMaMH(maMH))
                            {
                                MessageBox.Show(this, "Mã môn học không tồn tại", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            else
                            {
                                MessageBox.Show(this, "Sửa không thành công", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                        }

                    }
                }
                catch
                {
                    MessageBox.Show(this, "Điểm phải có dạng chữ số", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }
            else
            {
                textBox1.ReadOnly = true;
                textBox2.ReadOnly = true;
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["MASV"].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["MAMH"].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["DIEMSO"].Value.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            clearForm();
            dataGridView1.DataSource = ds.getAll();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show(this, "Vui lòng nhập đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                DialogResult = MessageBox.Show("Bạn có muốn xóa không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.No)
                {
                    return;
                }
                else
                {
                    string maSV = textBox1.Text;
                    string MaMH = textBox2.Text;
                    bool kq = ds.xoa(maSV, MaMH);
                    if (kq)
                    {
                        LoadTable();
                        clearForm();
                    }
                    else
                    {
                        if (!ds1.checkMa(maSV))
                        {
                            MessageBox.Show(this, "Mã sinh viên không tồn tại", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        if (!ds2.checkMaMH(MaMH))
                        {
                            MessageBox.Show(this, "Mã môn học không tồn tại", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        else
                        {
                            MessageBox.Show(this, "Xóa không thành công ", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult = MessageBox.Show("Bạn có chắc muốn đóng không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DialogResult == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                return;
            }
        }
    }
}
