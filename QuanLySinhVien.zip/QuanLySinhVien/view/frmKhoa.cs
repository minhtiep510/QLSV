﻿using QuanLySinhVien.Database;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.view
{
    public partial class frmKhoa : Form
    {
        private QuanLyKhoa ds = new QuanLyKhoa();
        public frmKhoa()
        {
            InitializeComponent();
        }
        public void loadTable()
        {
            dataGridView1.DataSource = ds.getAll();
            dataGridView1.Columns[0].HeaderText = "Mã Khoa";
            dataGridView1.Columns[1].HeaderText = "Tên Khoa";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string maKhoa = textBox1.Text;
            string tenKhoa = textBox2.Text;
            if (maKhoa == "" || tenKhoa == "")
            {
                MessageBox.Show(this, "Vui lòng điền đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool kq = ds.Them(new Khoa(maKhoa, tenKhoa));
                if (kq)
                {
                    loadTable();
                    clearForm();
                }
                else
                {
                    bool kq1 = ds.checkMa(maKhoa);

                    if (kq1)
                    {
                        MessageBox.Show(this, "Thêm không thành công. Mã khoa đã tồn tại.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show(this, "Thêm không thành công.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            clearForm();
           
        }
        public void clearForm()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox1.ReadOnly = false;
            loadTable();
            textBox3.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox1.ReadOnly = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string makhoa = textBox1.Text;
            string tenkhoa = textBox2.Text;
            if (makhoa == "" || tenkhoa == "")
            {
                MessageBox.Show("Vui lòng nhập đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool kq = ds.Sua(new Khoa(makhoa, tenkhoa));
                if (kq)
                {
                    loadTable();
                    clearForm();
                }
                else
                {
                    MessageBox.Show("Sửa không thành công", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string makhoa = textBox1.Text;
            if (makhoa == "")
            {
                MessageBox.Show("Vui lòng nhập mã khoa", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult = MessageBox.Show("Bạn có muốn xóa không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.No)
                {
                    return;
                }
                else
                {
                    bool kq = ds.Xoa(makhoa);
                    if (kq)
                    {
                        loadTable();
                        clearForm();
                    }
                    else
                    {
                        MessageBox.Show("Xóa không thành công.Đang có học lớp học thuộc khoa này", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc muốn thoát không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
                MainForm mf = new MainForm();
                mf.Show();
            }
            else
            {
                return;
            }
        }

        private void KhoaView_Load(object sender, EventArgs e)
        {
            loadTable();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                MessageBox.Show("Chưa nhập thông tin","Cảnh báo",MessageBoxButtons.YesNo,MessageBoxIcon.Error);
                return; 
            }
            string maKhoa = textBox3.Text;
            
            bool kq = ds.checkMa(maKhoa);
          
            if (!kq)
            {
                MessageBox.Show("Không có khoa này","Xác nhận",MessageBoxButtons.OK);
                return;
            }
            else
            {
                dataGridView1.DataSource = ds.timkiemMa(maKhoa);
            }
        }
    }
}
