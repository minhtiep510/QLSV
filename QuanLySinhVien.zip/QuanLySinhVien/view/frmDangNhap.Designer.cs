﻿namespace QuanLySinhVien
{
    partial class frmDangNhap
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDangNhap));
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            radioButton1 = new RadioButton();
            label1 = new Label();
            button1 = new Button();
            textPass = new TextBox();
            textUser = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(181, 356);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.Control;
            panel2.Controls.Add(radioButton1);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(textPass);
            panel2.Controls.Add(textUser);
            panel2.Controls.Add(pictureBox1);
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(610, 355);
            panel2.TabIndex = 0;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButton1.Location = new Point(416, 224);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(130, 21);
            radioButton1.TabIndex = 6;
            radioButton1.TabStop = true;
            radioButton1.Text = "Hiển thị mật khẩu";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged;
            radioButton1.Click += radioButton1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(307, 46);
            label1.Name = "label1";
            label1.Size = new Size(192, 38);
            label1.TabIndex = 5;
            label1.Text = "Login System";
            // 
            // button1
            // 
            button1.BackColor = Color.Lime;
            button1.Location = new Point(319, 270);
            button1.Name = "button1";
            button1.Size = new Size(162, 36);
            button1.TabIndex = 2;
            button1.Text = "Login";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textPass
            // 
            textPass.Location = new Point(265, 179);
            textPass.Name = "textPass";
            textPass.PlaceholderText = "Password";
            textPass.Size = new Size(284, 27);
            textPass.TabIndex = 5;
            textPass.UseSystemPasswordChar = true;
            // 
            // textUser
            // 
            textUser.Location = new Point(265, 115);
            textUser.Name = "textUser";
            textUser.PlaceholderText = "Username";
            textUser.Size = new Size(284, 27);
            textUser.TabIndex = 4;
            // 
            // frmDangNhap
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(610, 357);
            Controls.Add(panel2);
            Name = "frmDangNhap";
            Text = "Đăng nhập";
            Load += frmDangNhap_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private PictureBox pictureBox1;
        private Panel panel2;
        private TextBox textUser;
        private Button button1;
        private TextBox textPass;
        private Label label1;
        private RadioButton radioButton1;
    }
}
