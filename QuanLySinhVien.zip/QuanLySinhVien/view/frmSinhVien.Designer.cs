﻿namespace QuanLySinhVien.view
{
    partial class frmSinhVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBox1 = new TextBox();
            label3 = new Label();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            txtNoiSinh = new TextBox();
            txtTen = new TextBox();
            txtEmail = new TextBox();
            txtSdt = new TextBox();
            txtMa = new TextBox();
            button1 = new Button();
            dateTimePicker1 = new DateTimePicker();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            lblNoiSinh = new Label();
            lblNgSinh = new Label();
            lblTen = new Label();
            lblMa = new Label();
            dgv = new DataGridView();
            label1 = new Label();
            groupBox2 = new GroupBox();
            button5 = new Button();
            label2 = new Label();
            textBox2 = new TextBox();
            button6 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackgroundImage = Properties.Resources.background;
            groupBox1.BackgroundImageLayout = ImageLayout.Stretch;
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(button4);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.Controls.Add(txtNoiSinh);
            groupBox1.Controls.Add(txtTen);
            groupBox1.Controls.Add(txtEmail);
            groupBox1.Controls.Add(txtSdt);
            groupBox1.Controls.Add(txtMa);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(dateTimePicker1);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(lblNoiSinh);
            groupBox1.Controls.Add(lblNgSinh);
            groupBox1.Controls.Add(lblTen);
            groupBox1.Controls.Add(lblMa);
            groupBox1.Location = new Point(-3, 70);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1002, 318);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(514, 253);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(147, 27);
            textBox1.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.FlatStyle = FlatStyle.System;
            label3.Location = new Point(398, 260);
            label3.Name = "label3";
            label3.Size = new Size(56, 20);
            label3.TabIndex = 3;
            label3.Text = "Mã lớp";
            // 
            // button4
            // 
            button4.BackColor = Color.Tomato;
            button4.Location = new Point(796, 246);
            button4.Name = "button4";
            button4.Size = new Size(116, 48);
            button4.TabIndex = 11;
            button4.Text = "Hủy";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Tomato;
            button3.Location = new Point(796, 175);
            button3.Name = "button3";
            button3.Size = new Size(116, 48);
            button3.TabIndex = 10;
            button3.Text = "Xóa";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Tomato;
            button2.Location = new Point(796, 95);
            button2.Name = "button2";
            button2.Size = new Size(116, 48);
            button2.TabIndex = 9;
            button2.Text = "Sửa";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(611, 50);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(50, 24);
            radioButton2.TabIndex = 5;
            radioButton2.TabStop = true;
            radioButton2.Text = "Nữ";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Location = new Point(514, 50);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(62, 24);
            radioButton1.TabIndex = 4;
            radioButton1.TabStop = true;
            radioButton1.Text = "Nam";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // txtNoiSinh
            // 
            txtNoiSinh.Location = new Point(154, 257);
            txtNoiSinh.Name = "txtNoiSinh";
            txtNoiSinh.Size = new Size(218, 27);
            txtNoiSinh.TabIndex = 3;
            // 
            // txtTen
            // 
            txtTen.Location = new Point(154, 123);
            txtTen.Name = "txtTen";
            txtTen.Size = new Size(218, 27);
            txtTen.TabIndex = 2;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(514, 196);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(218, 27);
            txtEmail.TabIndex = 6;
            // 
            // txtSdt
            // 
            txtSdt.Location = new Point(514, 123);
            txtSdt.Name = "txtSdt";
            txtSdt.Size = new Size(218, 27);
            txtSdt.TabIndex = 5;
            // 
            // txtMa
            // 
            txtMa.Location = new Point(154, 50);
            txtMa.Name = "txtMa";
            txtMa.Size = new Size(218, 27);
            txtMa.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = Color.Tomato;
            button1.Location = new Point(796, 26);
            button1.Name = "button1";
            button1.Size = new Size(116, 48);
            button1.TabIndex = 8;
            button1.Text = "Thêm";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.Location = new Point(154, 191);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(218, 27);
            dateTimePicker1.TabIndex = 2;
            dateTimePicker1.Value = new DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(398, 196);
            label7.Name = "label7";
            label7.Size = new Size(46, 20);
            label7.TabIndex = 6;
            label7.Text = "Email";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(398, 123);
            label6.Name = "label6";
            label6.Size = new Size(97, 20);
            label6.TabIndex = 5;
            label6.Text = "Số điện thoại";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(398, 50);
            label5.Name = "label5";
            label5.Size = new Size(65, 20);
            label5.TabIndex = 4;
            label5.Text = "Giới tính";
            // 
            // lblNoiSinh
            // 
            lblNoiSinh.AutoSize = true;
            lblNoiSinh.Location = new Point(35, 260);
            lblNoiSinh.Name = "lblNoiSinh";
            lblNoiSinh.Size = new Size(63, 20);
            lblNoiSinh.TabIndex = 3;
            lblNoiSinh.Text = "Nơi sinh";
            // 
            // lblNgSinh
            // 
            lblNgSinh.AutoSize = true;
            lblNgSinh.Location = new Point(35, 190);
            lblNgSinh.Name = "lblNgSinh";
            lblNgSinh.Size = new Size(74, 20);
            lblNgSinh.TabIndex = 2;
            lblNgSinh.Text = "Ngày sinh";
            // 
            // lblTen
            // 
            lblTen.AutoSize = true;
            lblTen.Location = new Point(35, 120);
            lblTen.Name = "lblTen";
            lblTen.Size = new Size(93, 20);
            lblTen.TabIndex = 1;
            lblTen.Text = "Tên sinh viên";
            // 
            // lblMa
            // 
            lblMa.AutoSize = true;
            lblMa.Location = new Point(35, 50);
            lblMa.Name = "lblMa";
            lblMa.Size = new Size(91, 20);
            lblMa.TabIndex = 0;
            lblMa.Text = "Mã sinh viên";
            // 
            // dgv
            // 
            dgv.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv.Location = new Point(22, 60);
            dgv.Name = "dgv";
            dgv.RowHeadersWidth = 51;
            dgv.Size = new Size(927, 223);
            dgv.TabIndex = 1;
            dgv.CellContentClick += dgv_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(375, 9);
            label1.Name = "label1";
            label1.Size = new Size(272, 41);
            label1.TabIndex = 2;
            label1.Text = "Quản Lý Sinh Viên";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button6);
            groupBox2.Controls.Add(textBox2);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(dgv);
            groupBox2.Location = new Point(10, 386);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(976, 300);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Danh sách";
            // 
            // button5
            // 
            button5.BackColor = Color.Red;
            button5.Location = new Point(1, 692);
            button5.Name = "button5";
            button5.Size = new Size(94, 35);
            button5.TabIndex = 4;
            button5.Text = "Quay lại";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 23);
            label2.Name = "label2";
            label2.Size = new Size(91, 20);
            label2.TabIndex = 2;
            label2.Text = "Mã sinh viên";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(152, 20);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(175, 27);
            textBox2.TabIndex = 3;
            // 
            // button6
            // 
            button6.Location = new Point(365, 19);
            button6.Name = "button6";
            button6.Size = new Size(117, 29);
            button6.TabIndex = 4;
            button6.Text = "Tìm kiếm";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // frmSinhVien
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(998, 739);
            Controls.Add(button5);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Name = "frmSinhVien";
            Text = "frmSinhVien";
            Load += SinhVienView_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private DateTimePicker dateTimePicker1;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label lblNoiSinh;
        private Label lblNgSinh;
        private Label lblTen;
        private Label lblMa;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private TextBox txtNoiSinh;
        private TextBox txtTen;
        private TextBox txtEmail;
        private TextBox txtSdt;
        private TextBox txtMa;
        private Button button1;
        private Button button4;
        private Button button3;
        private Button button2;
        private DataGridView dgv;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private DataGridViewTextBoxColumn Column7;
        private TextBox textBox1;
        private Label label3;
        private Label label1;
        private GroupBox groupBox2;
        private Button button5;
        private Button button6;
        private TextBox textBox2;
        private Label label2;
    }
}