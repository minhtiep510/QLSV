﻿namespace QuanLySinhVien
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            label1 = new Label();
            button7 = new Button();
            groupBox1 = new GroupBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            groupBox2 = new GroupBox();
            label5 = new Label();
            label6 = new Label();
            groupBox3 = new GroupBox();
            label7 = new Label();
            label8 = new Label();
            groupBox4 = new GroupBox();
            label9 = new Label();
            label10 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(10, 150);
            button1.Name = "button1";
            button1.Size = new Size(160, 70);
            button1.TabIndex = 2;
            button1.Text = "Quản Lý Khoa";
            button1.UseVisualStyleBackColor = true;
            button1.UseWaitCursor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(10, 350);
            button2.Name = "button2";
            button2.Size = new Size(160, 70);
            button2.TabIndex = 3;
            button2.Text = "Quản Lý Sinh Viên";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(12, 250);
            button3.Name = "button3";
            button3.Size = new Size(160, 70);
            button3.TabIndex = 4;
            button3.Text = "Quản Lý Lớp Học";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(10, 450);
            button4.Name = "button4";
            button4.Size = new Size(160, 70);
            button4.TabIndex = 5;
            button4.Text = "Điểm ";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(10, 550);
            button5.Name = "button5";
            button5.Size = new Size(160, 70);
            button5.TabIndex = 6;
            button5.Text = "Quản Lý Môn Học";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(10, 750);
            button6.Name = "button6";
            button6.Size = new Size(160, 70);
            button6.TabIndex = 7;
            button6.Text = "Đăng xuất";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.MistyRose;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(636, 46);
            label1.Name = "label1";
            label1.Size = new Size(706, 54);
            label1.TabIndex = 8;
            label1.Text = "Phần mềm quản lý thông tin Sinh Viên";
            // 
            // button7
            // 
            button7.Location = new Point(10, 870);
            button7.Name = "button7";
            button7.Size = new Size(160, 70);
            button7.TabIndex = 9;
            button7.Text = "Đổi mật khẩu";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Location = new Point(259, 221);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(250, 126);
            groupBox1.TabIndex = 10;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tổng quan";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Blue;
            label4.Location = new Point(26, 71);
            label4.Name = "label4";
            label4.Size = new Size(76, 31);
            label4.TabIndex = 1;
            label4.Text = "label4";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.AppWorkspace;
            label3.Location = new Point(26, 29);
            label3.Name = "label3";
            label3.Size = new Size(56, 23);
            label3.TabIndex = 0;
            label3.Text = "KHOA";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(926, 168);
            label2.Name = "label2";
            label2.Size = new Size(262, 31);
            label2.TabIndex = 11;
            label2.Text = "Tổng quan về hệ thống";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label6);
            groupBox2.Location = new Point(696, 221);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(250, 126);
            groupBox2.TabIndex = 11;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tổng quan";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Blue;
            label5.Location = new Point(26, 71);
            label5.Name = "label5";
            label5.Size = new Size(76, 31);
            label5.TabIndex = 1;
            label5.Text = "label5";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.AppWorkspace;
            label6.Location = new Point(26, 29);
            label6.Name = "label6";
            label6.Size = new Size(82, 23);
            label6.TabIndex = 0;
            label6.Text = "LỚP HỌC";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(label8);
            groupBox3.Location = new Point(1133, 221);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(250, 126);
            groupBox3.TabIndex = 12;
            groupBox3.TabStop = false;
            groupBox3.Text = "Tổng quan";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Blue;
            label7.Location = new Point(26, 71);
            label7.Name = "label7";
            label7.Size = new Size(76, 31);
            label7.TabIndex = 1;
            label7.Text = "label7";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.AppWorkspace;
            label8.Location = new Point(26, 29);
            label8.Name = "label8";
            label8.Size = new Size(92, 23);
            label8.TabIndex = 0;
            label8.Text = "MÔN HỌC";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(label9);
            groupBox4.Controls.Add(label10);
            groupBox4.Location = new Point(1565, 221);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(250, 126);
            groupBox4.TabIndex = 13;
            groupBox4.TabStop = false;
            groupBox4.Text = "Tổng quan";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Blue;
            label9.Location = new Point(26, 71);
            label9.Name = "label9";
            label9.Size = new Size(76, 31);
            label9.TabIndex = 1;
            label9.Text = "label9";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = SystemColors.AppWorkspace;
            label10.Location = new Point(26, 29);
            label10.Name = "label10";
            label10.Size = new Size(92, 23);
            label10.TabIndex = 0;
            label10.Text = "SINH VIÊN";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.images;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1804, 1028);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(label2);
            Controls.Add(groupBox1);
            Controls.Add(button7);
            Controls.Add(label1);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Cursor = Cursors.No;
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Panel panel1;
        private Label label1;
        private Button button7;
        private GroupBox groupBox1;
        private Label label3;
        private Label label2;
        private Label label4;
        private GroupBox groupBox2;
        private Label label5;
        private Label label6;
        private GroupBox groupBox3;
        private Label label7;
        private Label label8;
        private GroupBox groupBox4;
        private Label label9;
        private Label label10;
    }
}