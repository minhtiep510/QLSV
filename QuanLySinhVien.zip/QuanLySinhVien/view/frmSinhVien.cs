﻿using QuanLySinhVien.Database;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.view
{
    public partial class frmSinhVien : Form
    {
        private QuanLySV ds = new QuanLySV();
        private QuanLyLopHoc ds1 = new QuanLyLopHoc();

        public frmSinhVien()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string maSV = txtMa.Text;
            string hoTen = txtTen.Text;
            DateTime ngaySinh = dateTimePicker1.Value;
            string gioiTinh;
            if (radioButton1.Checked)
            {
                gioiTinh = "Nam";
            }
            else
            {
                gioiTinh = "Nữ";
            }
            string noiSinh = txtNoiSinh.Text;
            string sdt = txtSdt.Text;
            string email = txtEmail.Text;
            string maLop = textBox1.Text;
            string pattern = @"^[0-9]{10}$";
            string patternEmail = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            if (maSV == "" || hoTen == "" || noiSinh == "" || sdt == "" || email == "" || maLop == "")
            {
                MessageBox.Show(this, "Vui lòng điền đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch(sdt, pattern))
            {
                MessageBox.Show(this, "Số điện thoại không hợp lệ", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch(email.Trim(), patternEmail))
            {
                MessageBox.Show(this, "Email không hợp lệ", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                bool kq = ds.them(new SinhVien(maSV, hoTen, ngaySinh, noiSinh, gioiTinh, sdt, email, maLop));
                if (kq)
                {
                    loadTable();
                    clearForm();
                }
                else
                {
                    bool kq1 = ds.checkMa(maSV);
                    bool kq2 = ds1.checkMa(maLop);
                    if (kq1)
                    {
                        MessageBox.Show(this, "Thêm không thành công. Mã sinh viên đã tồn tại.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else if (!kq2)
                    {
                        MessageBox.Show(this, "Thêm không thành công. Chưa có mã lớp này.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        MessageBox.Show(this, "Thêm không thành công.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                }
            }



        }
        public void loadTable()
        {
            dgv.DataSource = ds.getAll();
            dgv.Columns["Ma"].DisplayIndex = 0;
            dgv.Columns["Ten"].DisplayIndex = 1;
            dgv.Columns["NgaySinh"].DisplayIndex = 2;
            dgv.Columns["NoiSinh"].DisplayIndex = 3;
            dgv.Columns["GioiTinh"].DisplayIndex = 4;
            dgv.Columns["SDT"].DisplayIndex = 5;
            dgv.Columns["Email"].DisplayIndex = 6;
            dgv.Columns["MaLop"].DisplayIndex = 7;
            dgv.Columns["Ma"].HeaderText = "Mã Sinh Viên";
            dgv.Columns["Ten"].HeaderText = "Họ Tên";
            dgv.Columns["NgaySinh"].HeaderText = "Ngày Sinh";
            dgv.Columns["NoiSinh"].HeaderText = "Nơi Sinh";
            dgv.Columns["GioiTinh"].HeaderText = "Giới Tính";
            dgv.Columns["SDT"].HeaderText = "Số Điện Thoại";
            dgv.Columns["Email"].HeaderText = "Email";
            dgv.Columns["MaLop"].HeaderText = "Mã Lớp";


        }
        public void clearForm()
        {
            txtMa.Text = "";
            txtTen.Text = "";
            txtNoiSinh.Text = "";
            txtSdt.Text = "";
            txtEmail.Text = "";
            textBox1.Text = "";
            txtMa.ReadOnly = false;
            radioButton1.Checked = true;
            dateTimePicker1.Value = new DateTime(2000, 1, 1);
            textBox2.Text = "";
            loadTable();
        }

        private void SinhVienView_Load(object sender, EventArgs e)
        {
            loadTable();
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            clearForm();
          
    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string maSV = txtMa.Text;
            string tenSV = txtTen.Text;
            DateTime ngaySinh = dateTimePicker1.Value;
            string gioiTinh;
            if (radioButton1.Checked)
            {
                gioiTinh = "Nam";
            }
            else
            {
                gioiTinh = "Nữ";
            }
            string noiSinh = txtNoiSinh.Text;
            string sdt = txtSdt.Text;
            string email = txtEmail.Text;
            string maLop = textBox1.Text;
            if (maSV == "" || tenSV == "" || noiSinh == "" || sdt == "" || email == "" || maLop == "")
            {
                MessageBox.Show(this, "Vui lòng điền đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            string pattern = "^[0-9]{10}$";
            string patternEmail = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$";
            if (!System.Text.RegularExpressions.Regex.IsMatch(sdt, pattern))
            {
                MessageBox.Show(this, "Số điện thoại không hợp lệ", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (!System.Text.RegularExpressions.Regex.IsMatch(email.Trim(), patternEmail))
            {
                MessageBox.Show(this, "Email không hợp lệ", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                bool kq = ds.Update(new SinhVien(maSV, tenSV, ngaySinh, noiSinh, gioiTinh, sdt, email, maLop));
                if (kq)
                {
                    loadTable();
                    clearForm();
                }
                else
                {
                    if (!ds.checkMa(maSV))
                    {
                        MessageBox.Show(this, "Sửa không thành công. Sinh viên không tồn tại.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else if (!ds1.checkMa(maLop))
                    {
                        MessageBox.Show(this, "Sửa không thành công. chưa có mã lớp này.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    {
                        MessageBox.Show(this, "Lỗi", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }
            txtMa.ReadOnly = true;
            txtMa.Text = dgv.Rows[e.RowIndex].Cells["MA"].Value.ToString();
            txtTen.Text = dgv.Rows[e.RowIndex].Cells["TEN"].Value.ToString();
            dateTimePicker1.Value = Convert.ToDateTime(dgv.Rows[e.RowIndex].Cells["NgaySinh"].Value.ToString());
            txtNoiSinh.Text = dgv.Rows[e.RowIndex].Cells["NoiSinh"].Value.ToString();
            string gt = dgv.Rows[e.RowIndex].Cells["GioiTinh"].Value.ToString();
            if (gt == "Nam")
            {
                radioButton1.Checked = true;
            }
            else
            {
                radioButton2.Checked = true;
            }
            txtSdt.Text = dgv.Rows[e.RowIndex].Cells["SDT"].Value.ToString();
            txtEmail.Text = dgv.Rows[e.RowIndex].Cells["Email"].Value.ToString();
            textBox1.Text = dgv.Rows[e.RowIndex].Cells["MALOP"].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)

        {

            string maSV = txtMa.Text;
            if (maSV == "")
            {
                MessageBox.Show(this, "Vui lòng chọn sinh viên cần xóa", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên này không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.No)
                {
                    return;
                }
                else
                {
                    bool kq = ds.Xoa(maSV);
                    if (kq)
                    {
                        loadTable();
                        clearForm();
                    }
                    else
                    {
                        if (!ds.checkMa(maSV))
                        {
                            MessageBox.Show(this, "Xóa không thành công. Sinh viên không tồn tại.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        else
                        {
                            MessageBox.Show(this, "Xóa không thành công.Có môn học vẫn có điểm của sinh viên này", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn quay lại không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
                MainForm mf = new MainForm();
                mf.Show();
            }
            else
            {
                return;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                MessageBox.Show("Chưa nhập thông tin", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                return;
            }
            string maSV = textBox2.Text;
            bool kq = ds.checkMa(maSV);
            if (!kq)
            {

                MessageBox.Show("Không có sinh viên này", "Xác nhận", MessageBoxButtons.OK);
                return;
            }
            else
            {
                dgv.DataSource= ds.timkiemMa(maSV);
            }
        }
    }
}
