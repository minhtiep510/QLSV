﻿using QuanLySinhVien.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.view
{
    public partial class frmMonHoc : Form
    {
        public QuanLyMonHoc ds = new QuanLyMonHoc();
        public frmMonHoc()
        {
            InitializeComponent();
        }

        private void MonHoc_Load(object sender, EventArgs e)
        {
            loadData();
        }
        public void loadData()
        {
            dataGridView1.DataSource = ds.getAll();
            // Đặt lại thứ tự cột (DisplayIndex)
            dataGridView1.Columns["MA"].DisplayIndex = 0;
            dataGridView1.Columns["TEN"].DisplayIndex = 1;
            dataGridView1.Columns["SoTiet"].DisplayIndex = 2;
            dataGridView1.Columns["HocKy"].DisplayIndex = 3;
            dataGridView1.Columns["MA"].HeaderText = "Mã Môn Học";
            dataGridView1.Columns["TEN"].HeaderText = "Tên Môn Học";
            dataGridView1.Columns["SOTIET"].HeaderText = "Số tiết";
            dataGridView1.Columns["HOCKY"].HeaderText = "Học kỳ";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show(this, "Vui lòng điền đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    string maMH = textBox1.Text;
                    string tenMH = textBox2.Text;
                    int soTiet = int.Parse(textBox3.Text);
                    int hocKy = int.Parse(textBox4.Text);

                    if (soTiet <= 0)
                    {
                        MessageBox.Show(this, "Số tiết học phải > 0", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (hocKy <= 0)
                    {
                        MessageBox.Show(this, "Học Kỳ phải là số nuyên dương", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        bool kq = ds.them(new Model.MonHoc(maMH, tenMH, soTiet, hocKy));
                        if (kq)
                        {
                            loadData();
                            clearForm();
                        }
                        else
                        {
                            bool kq1 = ds.checkMaMH(maMH);
                            if (kq1)
                            {
                                MessageBox.Show(this, "Thêm không thành công. Mã môn học đã tồn tại.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                MessageBox.Show(this, "Thêm không thành công", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show(this, "Số tiết học và học kỳ phải là số nguyên", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        public void clearForm()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox1.ReadOnly = false;
            textBox5.Text = "";
            loadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }
            textBox1.ReadOnly = true;
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["MA"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["TEN"].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["SOTIET"].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["HocKy"].Value.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show(this, "Vui lòng điền đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    string maMH = textBox1.Text;
                    string tenMH = textBox2.Text;
                    int soTiet = int.Parse(textBox3.Text);
                    int hocKy = int.Parse(textBox4.Text);

                    if (soTiet <= 0)
                    {
                        MessageBox.Show(this, "Số tiết học phải > 0", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (hocKy <= 0)
                    {
                        MessageBox.Show(this, "Học Kỳ phải là số nuyên dương", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        bool kq = ds.sua(new Model.MonHoc(maMH, tenMH, soTiet, hocKy));
                        if (kq)
                        {
                            loadData();
                            clearForm();
                        }
                        else
                        {
                            bool kq1 = ds.checkMaMH(maMH);
                            if (!kq1)
                            {
                                MessageBox.Show(this, "Không tồn tại môn học này.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                MessageBox.Show(this, "Thêm không thành công", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show(this, "Số tiết học và học kỳ phải là số nguyên", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string maMH = textBox1.Text;
            if (maMH == "")
            {
                MessageBox.Show(this, "Vui lòng nhập mã môn học cần xóa", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
            {
                DialogResult = MessageBox.Show("Bạn có muốn xóa không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.No)
                {
                    return;
                }
                else
                {
                    bool kq = ds.xoa(maMH);
                    if (kq)
                    {
                        loadData();
                        clearForm();
                    }
                    else
                    {
                        bool kq1 = ds.checkMaMH(maMH);
                        if (!kq1)
                        {
                            MessageBox.Show(this, "Không tồn tại môn học này.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show(this, "Xóa không thành công có học sinh vẫn có điểm môn này.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            clearForm();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult = MessageBox.Show("Bạn có muốn quay lại không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DialogResult == DialogResult.Yes)
            {
                this.Close();
                MainForm mf = new MainForm();
                mf.Show();
            }
            else
            {
                return;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                MessageBox.Show("Chưa nhập thông tin", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                return;
            }
            string maMH = textBox5.Text;
            bool kq = ds.checkMaMH(maMH);
            if (!kq)
            {
                MessageBox.Show("Không có môn học này", "Xác nhận", MessageBoxButtons.OK);
                return;
            }
            else
            {
                dataGridView1.DataSource = ds.timkiemMa(maMH);
            }
        }
    }
}
