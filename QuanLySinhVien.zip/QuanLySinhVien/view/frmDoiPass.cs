﻿using QuanLySinhVien.Database;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.view
{
    public partial class frmDoiPass : Form
    {
        QuanLyDangNhap control = new QuanLyDangNhap();
        public frmDoiPass()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string username = textBox1.Text;
            string oldPass = textBox2.Text;
            string newPass = textBox3.Text;
            string confirmPass = textBox4.Text;
            if (username == "" || oldPass == "" || newPass == "" || confirmPass == "")
            {
                MessageBox.Show(this, "Vui lòng điền đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string pattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$";
                if (newPass != confirmPass)
                {
                    MessageBox.Show(this, "Mật khẩu mới và xác nhận mật khẩu không khớp", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else if (!System.Text.RegularExpressions.Regex.IsMatch(newPass, pattern))
                {
                    MessageBox.Show(this, "Mật khẩu mới phải có ít nhất 6 ký tự, bao gồm chữ hoa, chữ thường và số.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    // Giả sử có hàm ChangePassword để đổi mật khẩu
                    bool result = control.DoiMatKhau(username, oldPass, newPass);
                    if (result)
                    {
                        clearForm();
                        MessageBox.Show(this, "Đổi mật khẩu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                    }
                    else
                    {
                        MessageBox.Show(this, "Đổi mật khẩu không thành công. Xem lại thông tin tài khoản và mật khẩu.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

            if (radioButton1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
                textBox3.UseSystemPasswordChar = false;
                textBox4.UseSystemPasswordChar = false;
            }
            else 
            {
                textBox2.UseSystemPasswordChar = true;
                textBox3.UseSystemPasswordChar = true;
                textBox4.UseSystemPasswordChar = true;
            }

        }



        private void frmDoiPass_Load(object sender, EventArgs e)
        {
            radioButton1.AutoCheck = false;
        }

        private void radioButton1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                radioButton1.Checked = false;
            }
            else
            {
                radioButton1.Checked = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc muốn hủy thay đổi mật khẩu không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                this.Close();
                MainForm mf = new MainForm();
                mf.Show();
            }
            else
            {
                return;
            }
        }
        public void clearForm()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }
    }
}
