﻿using QuanLySinhVien.Database;
using QuanLySinhVien.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien.view
{
    public partial class LopHocView : Form
    {
        private QuanLyLopHoc ds = new QuanLyLopHoc();


        public LopHocView()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || comboBox1.SelectedItem.ToString() == "")
            {
                MessageBox.Show(this, "Vui lòng nhập đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            else
            {
                try
                {
                    string maLop = textBox1.Text;
                    string tenLop = textBox2.Text;
                    int siSo = Convert.ToInt32(textBox3.Text);
                    string maKhoa = comboBox1.SelectedItem.ToString();
                    if (siSo < 0)
                    {
                        MessageBox.Show(this, "Sĩ số học sinh phải >0", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        bool kq = ds.Them(new LopHoc(maLop, tenLop, siSo, maKhoa));
                        if (kq)
                        {
                            loadTable();
                            clearForm();
                        }
                        else
                        {
                            bool kq1 = ds.checkMa(maLop);
                            if (kq1)
                            {
                                MessageBox.Show(this, "Thêm không thành công. Mã lớp đã tồn tại.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                MessageBox.Show(this, "Thêm không thành công.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Sĩ số đăng kí phải là số nguyên", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void loadKhoa()
        {
            QuanLyKhoa qlk = new QuanLyKhoa();
            List<string> listKhoa = qlk.getMa();
            foreach (string i in listKhoa)
            {
                comboBox1.Items.Add(i);
            }

        }
        public void loadTable()
        {
            dataGridView1.DataSource = ds.getAll();
            dataGridView1.Columns["MA"].DisplayIndex = 0;
            dataGridView1.Columns["TEN"].DisplayIndex = 1;
            dataGridView1.Columns["SISO"].DisplayIndex = 2;
            dataGridView1.Columns["MAKHOA"].DisplayIndex = 3;

            dataGridView1.Columns["MA"].HeaderText = "Mã Lớp Học";
            dataGridView1.Columns["TEN"].HeaderText = "Tên Lớp Học";
            dataGridView1.Columns["SISO"].HeaderText = "Sĩ Số Đăng Kí";
            dataGridView1.Columns["MAKHOA"].HeaderText = "Mã Khoa";

        }
        public void clearForm()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            comboBox1.SelectedIndex = -1;
            textBox1.ReadOnly = false;
            loadTable();
        }
        private void LopHocView_Load(object sender, EventArgs e)
        {
            loadKhoa();
            loadTable();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.ReadOnly = true;
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["MA"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["TEN"].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["SISO"].Value.ToString();
            comboBox1.SelectedItem = dataGridView1.Rows[e.RowIndex].Cells["MAKHOA"].Value.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || comboBox1.SelectedItem.ToString() == "")
            {
                MessageBox.Show(this, "Vui lòng nhập đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            else
            {
                try
                {
                    string maLop = textBox1.Text;
                    string tenLop = textBox2.Text;
                    int siSo = Convert.ToInt32(textBox3.Text);
                    string maKhoa = comboBox1.SelectedItem.ToString();
                    if (siSo < 0)
                    {
                        MessageBox.Show(this, "Sĩ số phải lớn hơn 0", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        bool kq = ds.Sua(new LopHoc(maLop, tenLop, siSo, maKhoa));
                        if (kq)
                        {
                            loadTable();
                            clearForm();
                        }
                        else
                        {
                            MessageBox.Show(this, "Sửa không thành công.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Sĩ số đăng kí là kiểu số nguyên", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string maLop = textBox1.Text;
            if (maLop == "")
            {
                MessageBox.Show(this, "Vui lòng nhập mã lớp", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult = MessageBox.Show("Bạn có muốn xóa không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult == DialogResult.No)
                {
                    return;
                }
                else
                {
                    bool kq = ds.Xoa(maLop);
                    if (kq)
                    {
                        loadTable();
                        clearForm();
                    }
                    else
                    {
                        if (!ds.checkMa(maLop))
                        {
                            MessageBox.Show(this, "Xóa không thành công. Lớp học không tồn tại.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        else
                        {
                            MessageBox.Show(this, "Xóa không thành công đang có học sinh thuộc lớp học này.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn quay lại không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
                MainForm mf = new MainForm();
                mf.Show();
            }
            else
            {
                return;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            clearForm();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {
                MessageBox.Show("Chưa nhập thông tin", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                return;
            }
            string maLop=textBox4.Text;
            bool kq = ds.checkMa(maLop);
            if (!kq)
            {
                MessageBox.Show("Không có lớp học này này", "Xác nhận", MessageBoxButtons.OK);
                return;
            }
            else
            {
                dataGridView1.DataSource = ds.timkiemMa(maLop);
            }
        }
    }
}
