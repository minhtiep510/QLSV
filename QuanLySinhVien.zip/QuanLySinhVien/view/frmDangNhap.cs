﻿using QuanLySinhVien.Database;

namespace QuanLySinhVien
{
    public partial class frmDangNhap : Form
    {
        private QuanLyDangNhap control = new QuanLyDangNhap();
        public frmDangNhap()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textUser.Text;
            string pass = textPass.Text;
            string pattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$";
            if (username == "" || pass == "")
            {
                MessageBox.Show(this, "Vui lòng điền đủ thông tin", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(pass, pattern))
                {
                    MessageBox.Show(this, "Mật khẩu phải có ít nhất 6 ký tự, bao gồm chữ hoa, chữ thường và số.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    bool kq = control.KiemTraDangNhap(username, pass);
                    if (kq == true)
                    {
                        MessageBox.Show(this, "Đăng nhập thành công");
                        MainForm mainForm = new MainForm();
                        mainForm.ShowDialog();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show(this, "Tài khoản và mật khẩu không đúng", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void radioButton1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked==true)
            {
                radioButton1.Checked = false;

            }
            else
            {
                radioButton1.Checked = true;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked==true)
            {
                textPass.UseSystemPasswordChar = false;
            }
            else
            {
                textPass.UseSystemPasswordChar = true;
            }
        }

        private void frmDangNhap_Load(object sender, EventArgs e)
        {
            radioButton1.AutoCheck=false;
        }
    }
}
