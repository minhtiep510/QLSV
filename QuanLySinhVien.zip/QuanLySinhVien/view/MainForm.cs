﻿using QuanLySinhVien.Database;
using QuanLySinhVien.view;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class MainForm : Form
    {   
        QuanLyKhoa ds= new QuanLyKhoa();
        QuanLyLopHoc ds1=new QuanLyLopHoc();
        QuanLyMonHoc ds2=new QuanLyMonHoc();
        QuanLySV ds3=new QuanLySV();
        public MainForm()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

     
        private void button1_Click(object sender, EventArgs e)
        {
            frmKhoa kv = new frmKhoa();
            kv.Show();
            this.Close();
        }
        

        private void button6_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn đăng xuất không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                return;
            }
            else
            {
                frmDangNhap dn = new frmDangNhap();
                dn.Show();
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmSinhVien sv = new frmSinhVien();
            sv.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LopHocView lp = new LopHocView();
            lp.Show();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmMonHoc mh = new frmMonHoc();
            mh.Show();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmDiem diem = new frmDiem();
            diem.Show();
            this.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

            label4.Text = ds.SoLuongKhoa().ToString();
            label5.Text = ds1.SoLuongLop().ToString();
            label7.Text = ds2.SoLuongMH().ToString();
            label9.Text = ds3.SoLuongSV().ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            frmDoiPass doiPass = new frmDoiPass();
            doiPass.Show();
        }

       
    }
}
